package com.turkeymod.worldgen;

import com.turkeymod.block.TurkeyNestBlock;
import com.turkeymod.entity.TurkeyEntity;
import com.turkeymod.registry.ModBlocks;
import com.turkeymod.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** A small camp: a central nest with eggs, side nests, hay bales, and a flock of turkeys. */
public class TurkeyNestFeature extends Feature<NoneFeatureConfiguration> {
    public TurkeyNestFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    private static boolean canPlace(WorldGenLevel level, BlockPos pos) {
        BlockState at = level.getBlockState(pos);
        return (at.isAir() || at.canBeReplaced()) && !at.liquid()
                && level.getBlockState(pos.below()).is(BlockTags.DIRT);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        BlockPos origin = ctx.origin();
        RandomSource random = ctx.random();

        if (!canPlace(level, origin)) return false;

        BlockState nest = ModBlocks.TURKEY_NEST.get().defaultBlockState();

        // central nest with 2-4 eggs
        level.setBlock(origin, nest.setValue(TurkeyNestBlock.EGGS, 2 + random.nextInt(3)), 2);

        // side nests with 0-2 eggs
        for (Direction dir : Direction.Plane.HORIZONTAL) {
            BlockPos p = origin.relative(dir);
            if (random.nextInt(4) != 0 && canPlace(level, p)) {
                level.setBlock(p, nest.setValue(TurkeyNestBlock.EGGS, random.nextInt(3)), 2);
            }
        }

        // hay bales at some corners
        for (int dx = -1; dx <= 1; dx += 2) {
            for (int dz = -1; dz <= 1; dz += 2) {
                BlockPos p = origin.offset(dx, 0, dz);
                if (random.nextBoolean() && canPlace(level, p)) {
                    level.setBlock(p, Blocks.HAY_BLOCK.defaultBlockState(), 2);
                }
            }
        }

        // the flock
        int count = 3 + random.nextInt(3);
        for (int i = 0; i < count; i++) {
            BlockPos sp = origin.offset(random.nextInt(9) - 4, 0, random.nextInt(9) - 4);
            if (!canPlace(level, sp) || !level.getBlockState(sp.above()).isAir()) continue;
            TurkeyEntity turkey = ModEntities.TURKEY.get().create(level.getLevel());
            if (turkey == null) continue;
            turkey.setMale(i % 2 == 0);
            turkey.moveTo(sp.getX() + 0.5, sp.getY(), sp.getZ() + 0.5, random.nextFloat() * 360.0F, 0.0F);
            turkey.finalizeSpawn(level, level.getCurrentDifficultyAt(sp), MobSpawnType.CHUNK_GENERATION, null);
            level.addFreshEntityWithPassengers(turkey);
        }
        return true;
    }
}
