package com.turkeymod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.turkeymod.TurkeyMod;
import com.turkeymod.entity.TurkeyEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Male + female turkey in one model (parts are toggled per sex). Texture size 128x128. */
public class TurkeyModel extends EntityModel<TurkeyEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(TurkeyMod.MODID, "turkey"), "main");

    private static final int MF = 15;   // male fan feathers
    private static final int FF = 9;    // female tail feathers
    private static final float DEG = (float) Math.PI / 180F;
    private static final int[][] MF_UV = {{23, 22}, {34, 22}, {45, 22}};
    private static final int[][] FF_UV = {{21, 41}, {30, 41}};

    private final ModelPart root, body, neck, neck2, head, tail;
    private final ModelPart rightWing, leftWing, rightLeg, leftLeg;
    private final ModelPart beard, throat, wattleM, wattleF, caruncle, snood, rightSpur, leftSpur;
    private final ModelPart[] mf = new ModelPart[MF];
    private final ModelPart[] ff = new ModelPart[FF];

    public TurkeyModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.beard = body.getChild("beard");
        this.neck = root.getChild("neck");
        this.throat = neck.getChild("throat");
        this.neck2 = neck.getChild("neck2");
        this.head = neck2.getChild("head");
        this.wattleM = head.getChild("wattle_m");
        this.wattleF = head.getChild("wattle_f");
        this.caruncle = head.getChild("caruncle");
        this.snood = head.getChild("snood");
        this.tail = root.getChild("tail");
        this.rightWing = root.getChild("right_wing");
        this.leftWing = root.getChild("left_wing");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
        this.rightSpur = rightLeg.getChild("spur");
        this.leftSpur = leftLeg.getChild("spur");
        for (int i = 0; i < MF; i++) mf[i] = tail.getChild("m" + i);
        for (int i = 0; i < FF; i++) ff[i] = tail.getChild("f" + i);
    }

    private static float mAngle(int i) { return (i - MF / 2) * 0.18F; }
    private static float fAngle(int i) { return (i - FF / 2) * 0.13F; }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = mesh.getRoot();

        // Body: core + feather coat (outer shell with scalloped holes) + breast + rump (+ coat)
        PartDefinition body = p.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4.5F, -4, -6.5F, 9, 8, 13)
                .texOffs(45, 0).addBox(-4.5F, -4, -6.5F, 9, 8, 13, new CubeDeformation(0.45F))
                .texOffs(77, 41).addBox(-3, -1, -8.5F, 6, 6, 2)
                .texOffs(0, 52).addBox(-3, -3, 6, 6, 4, 3)
                .texOffs(19, 52).addBox(-3, -3, 6, 6, 4, 3, new CubeDeformation(0.4F)),
                PartPose.offsetAndRotation(0, 12, 0, -0.15F, 0, 0));
        body.addOrReplaceChild("beard", CubeListBuilder.create()
                .texOffs(38, 52).addBox(-0.5F, 2, -9, 1, 6, 1), PartPose.ZERO);

        // S-shaped neck -> head
        PartDefinition neck = p.addOrReplaceChild("neck", CubeListBuilder.create()
                .texOffs(92, 22).addBox(-2, -6, -2, 4, 6, 4),
                PartPose.offsetAndRotation(0, 10, -6, 0.35F, 0, 0));
        neck.addOrReplaceChild("throat", CubeListBuilder.create()
                .texOffs(50, 52).addBox(-1.5F, -5, -3, 3, 5, 1), PartPose.ZERO);
        PartDefinition neck2 = neck.addOrReplaceChild("neck2", CubeListBuilder.create()
                .texOffs(94, 41).addBox(-1.5F, -5, -1.5F, 3, 5, 3),
                PartPose.offsetAndRotation(0, -6, 0, -0.5F, 0, 0));
        PartDefinition head = neck2.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 41).addBox(-2.5F, -5, -2.5F, 5, 5, 5)
                .texOffs(59, 52).addBox(-1, -3, -5.5F, 2, 2, 3),
                PartPose.offsetAndRotation(0, -5, 0, 0.15F, 0, 0));
        head.addOrReplaceChild("wattle_m", CubeListBuilder.create()
                .texOffs(43, 52).addBox(-1, 0, -3, 2, 6, 1), PartPose.ZERO);
        head.addOrReplaceChild("wattle_f", CubeListBuilder.create()
                .texOffs(102, 52).addBox(-0.5F, 0, -3, 1, 3, 1), PartPose.ZERO);
        head.addOrReplaceChild("caruncle", CubeListBuilder.create()
                .texOffs(107, 52).addBox(-1.5F, -6, -1.5F, 3, 1, 3), PartPose.ZERO);
        head.addOrReplaceChild("snood", CubeListBuilder.create()
                .texOffs(120, 52).addBox(-0.5F, -5, -4.5F, 1, 3, 1), PartPose.ZERO);

        // Tail: base coverts + male fan (15 feathers) + female folded tail (9 shorter feathers)
        PartDefinition tail = p.addOrReplaceChild("tail", CubeListBuilder.create()
                .texOffs(70, 52).addBox(-4, -3, -1, 8, 3, 2),
                PartPose.offsetAndRotation(0, 11, 7, -0.3F, 0, 0));
        for (int i = 0; i < MF; i++) {
            int[] t = MF_UV[i % 3];
            tail.addOrReplaceChild("m" + i, CubeListBuilder.create()
                    .texOffs(t[0], t[1]).addBox(-2, -14, 0, 4, 14, 1),
                    PartPose.offsetAndRotation(0, 0, (i % 3) * 0.3F, 0, 0, mAngle(i)));
        }
        for (int i = 0; i < FF; i++) {
            int[] t = FF_UV[i % 2];
            tail.addOrReplaceChild("f" + i, CubeListBuilder.create()
                    .texOffs(t[0], t[1]).addBox(-1.5F, -9, 0, 3, 9, 1),
                    PartPose.offsetAndRotation(0, 0, (i % 2) * 0.3F, 0, 0, fAngle(i)));
        }

        // Wings: coverts + coat, outer layer, drooping primaries
        p.addOrReplaceChild("right_wing", CubeListBuilder.create()
                .texOffs(90, 0).addBox(-1, 0, -5, 1, 8, 10)
                .texOffs(0, 22).addBox(-1, 0, -5, 1, 8, 10, new CubeDeformation(0.35F))
                .texOffs(56, 22).addBox(-2, 1, -3, 1, 7, 8)
                .texOffs(75, 22).addBox(-2, 5, 1, 1, 6, 7),
                PartPose.offset(-4.5F, 9, 0));
        p.addOrReplaceChild("left_wing", CubeListBuilder.create()
                .texOffs(90, 0).addBox(0, 0, -5, 1, 8, 10)
                .texOffs(0, 22).addBox(0, 0, -5, 1, 8, 10, new CubeDeformation(0.35F))
                .texOffs(56, 22).addBox(1, 1, -3, 1, 7, 8)
                .texOffs(75, 22).addBox(1, 5, 1, 1, 6, 7),
                PartPose.offset(4.5F, 9, 0));

        // Legs: feathered thigh (with coat), drumstick, 4 toes, spur (male only)
        PartDefinition rl = p.addOrReplaceChild("right_leg", legCubes(), PartPose.offset(-2.5F, 15, 1));
        PartDefinition ll = p.addOrReplaceChild("left_leg", legCubes(), PartPose.offset(2.5F, 15, 1));
        rl.addOrReplaceChild("spur", CubeListBuilder.create()
                .texOffs(16, 60).addBox(-0.5F, 3, 1, 1, 2, 1), PartPose.ZERO);
        ll.addOrReplaceChild("spur", CubeListBuilder.create()
                .texOffs(16, 60).addBox(-0.5F, 3, 1, 1, 2, 1), PartPose.ZERO);

        return LayerDefinition.create(mesh, 128, 128);
    }

    private static CubeListBuilder legCubes() {
        return CubeListBuilder.create()
                .texOffs(39, 41).addBox(-2, -2, -2.5F, 4, 4, 5)
                .texOffs(58, 41).addBox(-2, -2, -2.5F, 4, 4, 5, new CubeDeformation(0.45F))
                .texOffs(107, 41).addBox(-1, 2, -1, 2, 6, 2)
                .texOffs(91, 52).addBox(-0.5F, 8, -4, 1, 1, 4)
                .texOffs(0, 60).addBox(-2, 8, -3, 1, 1, 3)
                .texOffs(0, 60).addBox(1, 8, -3, 1, 1, 3)
                .texOffs(9, 60).addBox(-0.5F, 8, 1, 1, 1, 2);
    }

    @Override
    public void setupAnim(TurkeyEntity e, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        boolean male = e.isMale();
        boolean sitting = e.isInSittingPose();

        // sex-specific parts
        beard.visible = male;
        throat.visible = male;
        wattleM.visible = male;
        caruncle.visible = male;
        snood.visible = male;
        wattleF.visible = !male;
        rightSpur.visible = male;
        leftSpur.visible = male;
        for (ModelPart f : mf) f.visible = male;
        for (ModelPart f : ff) f.visible = !male;

        root.y = sitting ? 7.0F : 0.0F;
        rightLeg.visible = !sitting;
        leftLeg.visible = !sitting;

        float walk = Mth.cos(limbSwing * 0.6662F);

        neck.xRot = 0.35F + Mth.sin(limbSwing * 1.3F) * 0.2F * limbSwingAmount;
        neck.yRot = netHeadYaw * DEG * 0.5F;
        head.xRot = 0.15F + headPitch * DEG;
        head.yRot = netHeadYaw * DEG * 0.5F;

        // pecking: the head darts forward and down while the turkey attacks
        if (this.attackTime > 0.0F) {
            float peck = Mth.sin(this.attackTime * (float) Math.PI);
            neck.xRot += 0.9F * peck;
            head.xRot += 0.6F * peck;
        }

        body.xRot = male ? -0.15F : -0.04F;
        body.zRot = walk * 0.05F * limbSwingAmount;

        rightLeg.xRot = walk * 1.0F * limbSwingAmount;
        leftLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.0F * limbSwingAmount;

        if (male) {
            tail.xRot = -0.3F;
            float idle = 1.0F + 0.02F * Mth.sin(ageInTicks * 0.08F);
            float open = Mth.lerp(Mth.clamp(limbSwingAmount * 3.0F, 0.0F, 1.0F), idle, 0.55F);
            if (sitting) open = 0.9F;
            for (int i = 0; i < MF; i++) mf[i].zRot = mAngle(i) * open;
        } else {
            tail.xRot = -1.05F;
            for (int i = 0; i < FF; i++) ff[i].zRot = fAngle(i);
        }

        float flap = e.onGround() ? 0.05F : (Mth.sin(ageInTicks * 1.3F) * 0.8F + 0.9F);
        rightWing.zRot = flap;
        leftWing.zRot = -flap;
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay, int color) {
        root.render(pose, buffer, light, overlay, color);
    }
}
