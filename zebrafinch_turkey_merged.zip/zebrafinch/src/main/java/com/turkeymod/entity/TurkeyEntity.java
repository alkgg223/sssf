package com.turkeymod.entity;

import com.turkeymod.block.TurkeyNestBlock;
import com.turkeymod.entity.ai.LayEggInNestGoal;
import com.turkeymod.registry.ModEntities;
import com.turkeymod.registry.ModItems;
import com.turkeymod.registry.ModSounds;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.UUID;

public class TurkeyEntity extends TamableAnimal {
    private static final Ingredient FOOD = Ingredient.of(
            Items.WHEAT_SEEDS, Items.BEETROOT_SEEDS, Items.MELON_SEEDS, Items.PUMPKIN_SEEDS);
    private static final EntityDataAccessor<Boolean> DATA_MALE =
            SynchedEntityData.defineId(TurkeyEntity.class, EntityDataSerializers.BOOLEAN);

    private int eggLayCooldown;   // females: time until the next egg
    private int eggWait;          // ticks the female has been "ready" without a nest to use
    private int dropCooldown;     // droppings
    private int featherCooldown;  // loose feathers

    public TurkeyEntity(EntityType<? extends TurkeyEntity> type, Level level) {
        super(type, level);
        this.entityData.set(DATA_MALE, this.random.nextBoolean());
        this.eggLayCooldown = 600 + this.random.nextInt(1800);
        this.dropCooldown = 1200 + this.random.nextInt(2400);
        this.featherCooldown = 1800 + this.random.nextInt(2400);
    }

    // ------------------------------------------------------------ sex

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_MALE, true);
    }

    public boolean isMale() {
        return this.entityData.get(DATA_MALE);
    }

    public void setMale(boolean male) {
        this.entityData.set(DATA_MALE, male);
    }

    // ------------------------------------------------------------ laying

    public boolean canLayEgg() {
        return !this.isMale() && !this.isBaby() && this.eggLayCooldown <= 0 && !this.isInSittingPose();
    }

    public void resetEggCooldown() {
        this.eggLayCooldown = 6000 + this.random.nextInt(6000);
        this.eggWait = 0;
    }

    /** Called by the nest goal so the turkey does not drop a loose egg while walking to a nest. */
    public void pauseEggDrop() {
        this.eggWait = 0;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide || this.isBaby()) return;

        if (this.eggLayCooldown > 0) this.eggLayCooldown--;

        // droppings -> craftable into bone meal
        if (--this.dropCooldown <= 0) {
            this.spawnAtLocation(ModItems.TURKEY_DROPPINGS.get());
            this.dropCooldown = 2400 + this.random.nextInt(3600);
        }
        // loose feathers
        if (--this.featherCooldown <= 0) {
            this.spawnAtLocation(Items.FEATHER);
            this.featherCooldown = 3000 + this.random.nextInt(4000);
        }
        // females without a nest nearby drop a big turkey egg on the ground
        if (!this.isMale() && this.eggLayCooldown <= 0 && !this.isInSittingPose()) {
            if (++this.eggWait >= 200) {
                this.playSound(SoundEvents.CHICKEN_EGG, 1.0F,
                        (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);
                this.spawnAtLocation(ModItems.TURKEY_EGG.get());
                this.resetEggCooldown();
            }
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("IsMale", this.isMale());
        tag.putInt("EggLayCooldown", this.eggLayCooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("IsMale")) this.setMale(tag.getBoolean("IsMale"));
        if (tag.contains("EggLayCooldown")) this.eggLayCooldown = tag.getInt("EggLayCooldown");
    }

    // ------------------------------------------------------------ attributes & goals

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 12.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ATTACK_DAMAGE, 3.0)
                .add(Attributes.FOLLOW_RANGE, 16.0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.5D) {
            @Override
            public boolean canUse() {
                return !TurkeyEntity.this.isTame() && super.canUse();
            }
        });
        this.goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.0D, 10.0F, 2.0F));
        this.goalSelector.addGoal(5, new LayEggInNestGoal(this));
        this.goalSelector.addGoal(5, new BreedGoal(this, 1.0D));
        this.goalSelector.addGoal(6, new TemptGoal(this, 1.1D, FOOD, false));
        this.goalSelector.addGoal(7, new FollowParentGoal(this, 1.1D));
        this.goalSelector.addGoal(8, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(9, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(10, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this) {
            @Override
            public boolean canUse() {
                return TurkeyEntity.this.isTame() && super.canUse();
            }
        });
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return FOOD.test(stack);
    }

    // ------------------------------------------------------------ taming

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (this.level().isClientSide) {
            boolean interactable = this.isTame() ? this.isOwnedBy(player) || this.isFood(stack)
                    : this.isFood(stack);
            return interactable ? InteractionResult.CONSUME : InteractionResult.PASS;
        }

        if (this.isTame()) {
            if (this.isFood(stack) && this.getHealth() < this.getMaxHealth()) {
                stack.consume(1, player);
                this.heal(4.0F);
                return InteractionResult.SUCCESS;
            }
            InteractionResult result = super.mobInteract(player, hand);
            if (!result.consumesAction() && this.isOwnedBy(player)) {
                this.setOrderedToSit(!this.isOrderedToSit());
                this.jumping = false;
                this.navigation.stop();
                this.setTarget(null);
                return InteractionResult.SUCCESS_NO_ITEM_USED;
            }
            return result;
        } else if (this.isFood(stack)) {
            stack.consume(1, player);
            if (this.random.nextInt(3) == 0) {
                this.tame(player);
                this.navigation.stop();
                this.setTarget(null);
                this.setOrderedToSit(true);
                this.level().broadcastEntityEvent(this, (byte) 7);
            } else {
                this.level().broadcastEntityEvent(this, (byte) 6);
            }
            return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, hand);
    }

    // ------------------------------------------------------------ breeding -> a nest appears, not a mob

    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        TurkeyEntity baby = ModEntities.TURKEY.get().create(level);
        if (baby != null) {
            UUID owner = this.getOwnerUUID();
            if (owner != null && this.isTame()) {
                baby.setOwnerUUID(owner);
                baby.setTame(true, true);
            }
        }
        return baby;
    }

    @Override
    public void spawnChildFromBreeding(ServerLevel level, Animal mate) {
        if (!TurkeyNestBlock.placeBreedingEgg(level, this.blockPosition())) {
            super.spawnChildFromBreeding(level, mate); // no room for a nest: normal baby
            return;
        }
        ServerPlayer player = this.getLoveCause();
        if (player == null) player = mate.getLoveCause();
        if (player != null) {
            player.awardStat(Stats.ANIMALS_BRED);
            CriteriaTriggers.BRED_ANIMALS.trigger(player, this, mate, null);
        }
        this.setAge(6000);
        mate.setAge(6000);
        this.resetLove();
        mate.resetLove();
        level.broadcastEntityEvent(this, (byte) 18);
        if (level.getGameRules().getBoolean(GameRules.RULE_DOMOBLOOT)) {
            level.addFreshEntity(new ExperienceOrb(level, this.getX(), this.getY(), this.getZ(),
                    this.getRandom().nextInt(7) + 1));
        }
    }

    @Override
    public boolean canMate(Animal other) {
        if (this.isOrderedToSit()) return false;
        return super.canMate(other);
    }

    // ------------------------------------------------------------ sounds

    @Override
    public int getAmbientSoundInterval() { return 240; }

    @Override
    protected SoundEvent getAmbientSound() { return ModSounds.TURKEY_AMBIENT.get(); }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return ModSounds.TURKEY_HURT.get(); }

    @Override
    protected SoundEvent getDeathSound() { return ModSounds.TURKEY_DEATH.get(); }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.CHICKEN_STEP, 0.15F, 1.0F);
    }
}
