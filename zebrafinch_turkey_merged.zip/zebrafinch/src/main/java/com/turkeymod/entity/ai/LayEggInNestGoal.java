package com.turkeymod.entity.ai;

import com.turkeymod.block.TurkeyNestBlock;
import com.turkeymod.entity.TurkeyEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;

/** Walks to the closest nest with free space and lays an egg in it. */
public class LayEggInNestGoal extends Goal {
    private static final int SEARCH_RADIUS = 14;
    private final TurkeyEntity turkey;
    private BlockPos target;
    private int timeout;

    public LayEggInNestGoal(TurkeyEntity turkey) {
        this.turkey = turkey;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    private static boolean hasRoom(Level level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return s.getBlock() instanceof TurkeyNestBlock && s.getValue(TurkeyNestBlock.EGGS) < TurkeyNestBlock.MAX_EGGS;
    }

    private BlockPos findNest() {
        Level level = turkey.level();
        BlockPos c = turkey.blockPosition();
        BlockPos min = c.offset(-SEARCH_RADIUS, -3, -SEARCH_RADIUS);
        BlockPos max = c.offset(SEARCH_RADIUS, 3, SEARCH_RADIUS);
        if (!level.hasChunksAt(min, max)) return null;
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(min, max)) {
            if (hasRoom(level, p)) {
                double d = p.distSqr(c);
                if (d < bestDist) {
                    bestDist = d;
                    best = p.immutable();
                }
            }
        }
        return best;
    }

    @Override
    public boolean canUse() {
        if (!turkey.canLayEgg()) return false;
        if (turkey.getRandom().nextInt(20) != 0) return false; // throttle the search
        this.target = findNest();
        return this.target != null;
    }

    @Override
    public boolean canContinueToUse() {
        return turkey.canLayEgg() && target != null && timeout > 0 && hasRoom(turkey.level(), target);
    }

    @Override
    public void start() {
        timeout = 600;
        turkey.pauseEggDrop();
        turkey.getNavigation().moveTo(target.getX() + 0.5, target.getY(), target.getZ() + 0.5, 1.0D);
    }

    @Override
    public void stop() {
        target = null;
        turkey.getNavigation().stop();
    }

    @Override
    public void tick() {
        timeout--;
        turkey.pauseEggDrop();
        double dx = target.getX() + 0.5 - turkey.getX();
        double dz = target.getZ() + 0.5 - turkey.getZ();
        if (dx * dx + dz * dz < 1.6D && Math.abs(target.getY() - turkey.getY()) < 1.5D) {
            if (TurkeyNestBlock.addEgg(turkey.level(), target)) {
                turkey.resetEggCooldown();
            }
            timeout = 0;
        } else if (turkey.getNavigation().isDone()) {
            turkey.getNavigation().moveTo(target.getX() + 0.5, target.getY(), target.getZ() + 0.5, 1.0D);
        }
    }
}
