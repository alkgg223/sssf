package com.turkeymod.item;

import com.turkeymod.block.TurkeyNestBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Big turkey egg. Right-click a Turkey Nest to place it; it hatches after 30 seconds. */
public class TurkeyEggItem extends Item {
    public TurkeyEggItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockPos pos = ctx.getClickedPos();
        if (level.getBlockState(pos).getBlock() instanceof TurkeyNestBlock) {
            if (!level.isClientSide && TurkeyNestBlock.addEgg(level, pos)) {
                ctx.getItemInHand().consume(1, ctx.getPlayer());
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
