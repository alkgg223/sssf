package com.turkeymod.block;

import com.mojang.serialization.MapCodec;
import com.turkeymod.entity.TurkeyEntity;
import com.turkeymod.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Straw nest. Each egg inside hatches into a baby turkey 30 seconds after it was laid.
 * A "temporary" nest (created when two turkeys breed) disappears once its egg has hatched.
 */
public class TurkeyNestBlock extends Block {
    public static final MapCodec<TurkeyNestBlock> CODEC = simpleCodec(TurkeyNestBlock::new);
    public static final int MAX_EGGS = 4;
    public static final int HATCH_TICKS = 600; // 30 seconds
    public static final IntegerProperty EGGS = IntegerProperty.create("eggs", 0, MAX_EGGS);
    public static final BooleanProperty TEMP = BooleanProperty.create("temp");
    private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 4, 16);

    public TurkeyNestBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(EGGS, 0).setValue(TEMP, false));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(EGGS, TEMP);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
    }

    @Override
    protected BlockState updateShape(BlockState state, Direction dir, BlockState neighbor,
                                     LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (dir == Direction.DOWN && !state.canSurvive(level, pos)) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, dir, neighbor, level, pos, neighborPos);
    }

    // ------------------------------------------------------------ hatching

    private static void scheduleHatch(Level level, BlockPos pos, BlockState state) {
        if (level.isClientSide || state.getValue(EGGS) <= 0) return;
        Block block = state.getBlock();
        if (!level.getBlockTicks().hasScheduledTick(pos, block)) {
            level.scheduleTick(pos, block, HATCH_TICKS);
        }
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moved) {
        scheduleHatch(level, pos, state);
    }

    @Override
    protected boolean isRandomlyTicking(BlockState state) {
        return state.getValue(EGGS) > 0;
    }

    /** Safety net: nests generated with the world get their hatch timer on the first random tick. */
    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        scheduleHatch(level, pos, state);
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        int eggs = state.getValue(EGGS);
        if (eggs <= 0) return;

        level.playSound(null, pos, SoundEvents.TURTLE_EGG_HATCH, SoundSource.BLOCKS,
                0.8F, 0.9F + random.nextFloat() * 0.2F);
        TurkeyEntity baby = ModEntities.TURKEY.get().create(level);
        if (baby != null) {
            baby.setAge(-24000);
            baby.moveTo(pos.getX() + 0.5, pos.getY() + 0.1, pos.getZ() + 0.5, random.nextFloat() * 360.0F, 0.0F);
            level.addFreshEntity(baby);
        }

        if (eggs > 1) {
            level.setBlock(pos, state.setValue(EGGS, eggs - 1), 2);
            level.scheduleTick(pos, this, HATCH_TICKS);
        } else if (state.getValue(TEMP)) {
            level.removeBlock(pos, false);
        } else {
            level.setBlock(pos, state.setValue(EGGS, 0), 2);
        }
    }

    // ------------------------------------------------------------ helpers

    public static boolean hasRoom(Level level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return s.getBlock() instanceof TurkeyNestBlock && s.getValue(EGGS) < MAX_EGGS;
    }

    /** Adds one egg if there is room and starts its 30 second hatch timer. */
    public static boolean addEgg(Level level, BlockPos pos) {
        if (!hasRoom(level, pos)) return false;
        BlockState state = level.getBlockState(pos);
        BlockState next = state.setValue(EGGS, state.getValue(EGGS) + 1);
        level.setBlock(pos, next, 2);
        scheduleHatch(level, pos, next);
        level.playSound(null, pos, SoundEvents.TURTLE_LAY_EGG, SoundSource.BLOCKS, 0.7F,
                0.9F + level.random.nextFloat() * 0.2F);
        return true;
    }

    /**
     * Called when two turkeys breed: puts an egg in a nearby nest, or builds a temporary nest
     * next to the parents. Returns false if there was no room at all.
     */
    public static boolean placeBreedingEgg(ServerLevel level, BlockPos center) {
        for (BlockPos p : BlockPos.betweenClosed(center.offset(-2, -1, -2), center.offset(2, 1, 2))) {
            if (hasRoom(level, p)) return addEgg(level, p.immutable());
        }
        List<BlockPos> spots = new ArrayList<>();
        for (BlockPos p : BlockPos.betweenClosed(center.offset(-2, 0, -2), center.offset(2, 0, 2))) {
            BlockState at = level.getBlockState(p);
            BlockPos below = p.below();
            if ((at.isAir() || at.canBeReplaced()) && !at.liquid()
                    && level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) {
                spots.add(p.immutable());
            }
        }
        if (spots.isEmpty()) return false;
        Collections.shuffle(spots);
        BlockPos spot = spots.get(0);
        BlockState nest = ModBlocksHolder.nest().defaultBlockState().setValue(EGGS, 1).setValue(TEMP, true);
        level.setBlock(spot, nest, 3);
        level.playSound(null, spot, SoundEvents.TURTLE_LAY_EGG, SoundSource.BLOCKS, 0.8F, 1.0F);
        return true;
    }

    /** Small indirection to avoid a static-init cycle with the registry class. */
    private static final class ModBlocksHolder {
        static Block nest() { return com.turkeymod.registry.ModBlocks.TURKEY_NEST.get(); }
    }
}
