package com.turkeymod.registry;

import com.turkeymod.TurkeyMod;
import com.turkeymod.entity.TurkeyEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, TurkeyMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<TurkeyEntity>> TURKEY =
            ENTITY_TYPES.register("turkey", () ->
                    EntityType.Builder.of(TurkeyEntity::new, MobCategory.CREATURE)
                            .sized(0.8F, 1.7F)
                            .clientTrackingRange(10)
                            .build("turkey"));
}
