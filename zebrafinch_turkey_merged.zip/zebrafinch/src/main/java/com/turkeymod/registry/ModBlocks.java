package com.turkeymod.registry;

import com.turkeymod.TurkeyMod;
import com.turkeymod.block.TurkeyNestBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(TurkeyMod.MODID);

    public static final DeferredBlock<TurkeyNestBlock> TURKEY_NEST = BLOCKS.registerBlock("turkey_nest",
            TurkeyNestBlock::new,
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_YELLOW)
                    .strength(0.5F)
                    .sound(SoundType.GRASS)
                    .noOcclusion()
                    .pushReaction(PushReaction.DESTROY));
}
