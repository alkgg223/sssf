package com.turkeymod.registry;

import com.turkeymod.TurkeyMod;
import com.turkeymod.worldgen.TurkeyNestFeature;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES =
            DeferredRegister.create(Registries.FEATURE, TurkeyMod.MODID);

    public static final DeferredHolder<Feature<?>, TurkeyNestFeature> TURKEY_NEST =
            FEATURES.register("turkey_nest", TurkeyNestFeature::new);
}
