package com.zebrafinch.mod;

import com.turkeymod.block.TurkeyNestBlock;
import com.turkeymod.entity.TurkeyEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.List;

public class RaccoonGoals {

    /** The raccoon notices a finch nest from this far away. */
    public static final double SEE_RANGE = 20.0D;
    /** Finches get a chance to spot the raccoon when it is this close to the nest. */
    public static final double NOTICE_RANGE = 3.0D;
    /** How far the raccoon looks for water after stealing an egg. */
    public static final int WATER_RANGE = 64;
    /** Chance (per adult finch) to notice the raccoon: with / without line of sight. */
    public static final float NOTICE_CHANCE_SEEN = 0.65F;
    public static final float NOTICE_CHANCE_HIDDEN = 0.20F;

    private static final double SNEAK_SPEED = 0.6D;
    private static final double RUN_SPEED = 1.7D;

    // ------------------------------------------------------------------ helpers

    /** A nest the raccoon wants to rob. */
    record NestTarget(BlockPos pos, boolean turkey) {}

    /** True while the nest still holds at least one egg. */
    static boolean hasEggs(ServerLevel level, BlockPos pos, boolean turkey) {
        BlockState state = level.getBlockState(pos);
        if (turkey) {
            return state.getBlock() instanceof TurkeyNestBlock && state.getValue(TurkeyNestBlock.EGGS) > 0;
        }
        return state.is(ModBlocks.NEST.get()) && state.getValue(FinchNestBlock.EGGS) > 0;
    }

    /** Nearest finch nest or turkey nest (that still holds eggs) within SEE_RANGE. */
    @Nullable
    static NestTarget findNest(ServerLevel level, Raccoon raccoon) {
        BlockPos origin = raccoon.blockPosition();
        int chunkRadius = ((int) SEE_RANGE >> 4) + 1;
        int cx = origin.getX() >> 4;
        int cz = origin.getZ() >> 4;
        double rangeSqr = SEE_RANGE * SEE_RANGE;
        Vec3 here = raccoon.position();
        BlockPos best = null;
        boolean bestTurkey = false;
        double bestDist = rangeSqr;
        net.minecraft.world.level.block.Block turkeyBlock = com.turkeymod.registry.ModBlocks.TURKEY_NEST.get();

        for (int x = cx - chunkRadius; x <= cx + chunkRadius; x++) {
            for (int z = cz - chunkRadius; z <= cz + chunkRadius; z++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(x, z);
                if (chunk == null) continue;

                // finch nests are block entities
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (!(be instanceof FinchNestBlockEntity)) continue;
                    BlockPos p = be.getBlockPos();
                    if (!hasEggs(level, p, false)) continue;
                    double d = here.distanceToSqr(Vec3.atCenterOf(p));
                    if (d < bestDist) {
                        bestDist = d;
                        best = p.immutable();
                        bestTurkey = false;
                    }
                }

                // turkey nests are plain blocks: only look into sections that contain one
                LevelChunkSection[] sections = chunk.getSections();
                for (int i = 0; i < sections.length; i++) {
                    LevelChunkSection section = sections[i];
                    if (section.hasOnlyAir() || !section.maybeHas(st -> st.is(turkeyBlock))) continue;
                    int baseY = chunk.getSectionYFromSectionIndex(i) << 4;
                    if (baseY > origin.getY() + SEE_RANGE || baseY + 15 < origin.getY() - SEE_RANGE) continue;
                    int baseX = chunk.getPos().getMinBlockX();
                    int baseZ = chunk.getPos().getMinBlockZ();
                    for (int lx = 0; lx < 16; lx++) {
                        for (int ly = 0; ly < 16; ly++) {
                            for (int lz = 0; lz < 16; lz++) {
                                if (!section.getBlockState(lx, ly, lz).is(turkeyBlock)) continue;
                                BlockPos p = new BlockPos(baseX + lx, baseY + ly, baseZ + lz);
                                if (!hasEggs(level, p, true)) continue;
                                double d = here.distanceToSqr(Vec3.atCenterOf(p));
                                if (d < bestDist) {
                                    bestDist = d;
                                    best = p;
                                    bestTurkey = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return best == null ? null : new NestTarget(best, bestTurkey);
    }

    /** Nearest water surface within the given radius (only already loaded chunks are looked at). */
    @Nullable
    static BlockPos findWater(ServerLevel level, BlockPos origin, int radius) {
        BlockPos best = null;
        int bestDist = Integer.MAX_VALUE;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                int d = dx * dx + dz * dz;
                if (d > radius * radius || d >= bestDist) continue;
                int x = origin.getX() + dx;
                int z = origin.getZ() + dz;
                if (!level.hasChunk(x >> 4, z >> 4)) continue;
                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z) - 1;
                m.set(x, y, z);
                if (level.getFluidState(m).is(FluidTags.WATER)) {
                    bestDist = d;
                    best = m.immutable();
                }
            }
        }
        return best;
    }

    /** Called while the raccoon is being chased: keeps nearby adult finches throwing droppings at it. */
    static void alertFinches(Raccoon raccoon) {
        if (!(raccoon.level() instanceof ServerLevel level)) return;
        List<ZebraFinch> birds = level.getEntitiesOfClass(ZebraFinch.class,
                raccoon.getBoundingBox().inflate(14.0D), b -> !b.isBaby() && b.isAlive());
        for (ZebraFinch bird : birds) {
            bird.setDefendTarget(raccoon);
        }
    }

    /**
     * Adult turkeys near the nest go for the raccoon and peck it. With useChance every turkey rolls to notice it,
     * otherwise all of them react. Returns true if at least one turkey is now chasing.
     */
    static boolean alertTurkeys(ServerLevel level, Raccoon raccoon, Vec3 center, double range, boolean useChance) {
        List<TurkeyEntity> turkeys = level.getEntitiesOfClass(TurkeyEntity.class,
                new AABB(center, center).inflate(range), t -> !t.isBaby() && t.isAlive() && !t.isOrderedToSit());
        boolean any = false;
        for (TurkeyEntity turkey : turkeys) {
            if (useChance) {
                float chance = turkey.hasLineOfSight(raccoon) ? NOTICE_CHANCE_SEEN : NOTICE_CHANCE_HIDDEN;
                if (turkey.getRandom().nextFloat() >= chance) continue;
            }
            turkey.setTarget(raccoon);
            turkey.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 2));
            any = true;
        }
        if (any) {
            raccoon.markChasedByTurkeys();
        }
        return any;
    }

    // ------------------------------------------------------------------ run away after being spotted / hit

    public static class ScaredRunGoal extends Goal {
        private final Raccoon raccoon;
        private int repath;

        public ScaredRunGoal(Raccoon raccoon) {
            this.raccoon = raccoon;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return raccoon.isScared();
        }

        @Override
        public boolean canContinueToUse() {
            return raccoon.isScared();
        }

        @Override
        public void start() {
            repath = 0;
            raccoon.setStalking(false);
        }

        @Override
        public void tick() {
            if (--repath <= 0 || raccoon.getNavigation().isDone()) {
                repath = 20;
                Vec3 from = raccoon.getScareFrom() != null ? raccoon.getScareFrom() : raccoon.position();
                Vec3 away = DefaultRandomPos.getPosAway(raccoon, 24, 8, from);
                if (away != null) {
                    raccoon.getNavigation().moveTo(away.x, away.y, away.z, RUN_SPEED);
                }
            }
        }
    }

    // ------------------------------------------------------------------ the whole heist

    public static class StealEggGoal extends Goal {
        private enum Phase { SEEK, RUN, WASH }

        private final Raccoon raccoon;
        private Phase phase = Phase.SEEK;
        @Nullable private BlockPos nest;
        private boolean turkeyNest;
        @Nullable private BlockPos water;
        private boolean noticeRolled;
        private boolean done;
        private int timer;
        private int repath;
        private int scanDelay;

        public StealEggGoal(Raccoon raccoon) {
            this.raccoon = raccoon;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (raccoon.level().isClientSide || raccoon.isScared() || raccoon.isBaby()) return false;
            if (raccoon.isCarryingEgg()) return true;       // e.g. after a reload / after being scared
            if (raccoon.getStealCooldown() > 0) return false;
            if (--scanDelay > 0) return false;
            scanDelay = 10;
            if (!(raccoon.level() instanceof ServerLevel server)) return false;
            NestTarget target = findNest(server, raccoon);
            if (target == null) return false;
            nest = target.pos();
            turkeyNest = target.turkey();
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return !done && !raccoon.isScared();
        }

        @Override
        public void start() {
            done = false;
            noticeRolled = false;
            timer = 0;
            repath = 0;
            if (raccoon.isCarryingEgg()) {
                if (raccoon.level() instanceof ServerLevel server) {
                    beginRun(server);
                }
            } else {
                phase = Phase.SEEK;
                raccoon.setStalking(true);
            }
        }

        @Override
        public void stop() {
            raccoon.setStalking(false);
            raccoon.setWashing(false);
            raccoon.setClimbHint(false);
            raccoon.getNavigation().stop();
            nest = null;
            water = null;
        }

        @Override
        public boolean isInterruptable() {
            return phase != Phase.WASH;
        }

        @Override
        public void tick() {
            if (!(raccoon.level() instanceof ServerLevel server)) return;
            timer++;
            if (phase != Phase.SEEK && !raccoon.isCarryingEgg()) {
                finish(3000);      // the egg went back to its nest
                return;
            }
            switch (phase) {
                case SEEK -> tickSeek(server);
                case RUN -> tickRun(server);
                case WASH -> tickWash(server);
            }
        }

        // ---------------- phase 1: sneak towards the nest
        private void tickSeek(ServerLevel server) {
            if (nest == null) {
                finish(600);
                return;
            }
            if (!hasEggs(server, nest, turkeyNest) || timer > 900) {
                finish(1200);
                return;
            }
            Vec3 c = Vec3.atCenterOf(nest);
            raccoon.setStalking(true);
            raccoon.setClimbHint(c.y > raccoon.getY() + 0.5D);
            raccoon.getLookControl().setLookAt(c.x, c.y, c.z);
            if (--repath <= 0) {
                repath = 10;
                raccoon.getNavigation().moveTo(c.x, c.y, c.z, SNEAK_SPEED);
            }

            double distSqr = raccoon.distanceToSqr(c);
            if (!noticeRolled && distSqr <= NOTICE_RANGE * NOTICE_RANGE) {
                noticeRolled = true;
                if (rollNotice(server, c)) {
                    raccoon.scare(240, !turkeyNest, c);
                    finish(1800);
                    return;
                }
            }
            if (distSqr <= 4.0D) {
                steal(server);
            }
        }

        /** Every adult finch (or turkey, for a turkey nest) near the nest gets a chance to spot the raccoon. */
        private boolean rollNotice(ServerLevel server, Vec3 nestCenter) {
            if (turkeyNest) {
                return alertTurkeys(server, raccoon, nestCenter, 14.0D, true);
            }
            AABB area = new AABB(nestCenter, nestCenter).inflate(14.0D);
            List<ZebraFinch> birds = server.getEntitiesOfClass(ZebraFinch.class, area,
                    b -> !b.isBaby() && b.isAlive());
            boolean noticed = false;
            for (ZebraFinch bird : birds) {
                float chance = bird.hasLineOfSight(raccoon) ? NOTICE_CHANCE_SEEN : NOTICE_CHANCE_HIDDEN;
                if (bird.getRandom().nextFloat() < chance) {
                    noticed = true;
                    bird.setDefendTarget(raccoon);
                }
            }
            return noticed;
        }

        private void steal(ServerLevel server) {
            if (nest == null) return;
            BlockState state = server.getBlockState(nest);
            if (turkeyNest) {
                int eggs = state.getValue(TurkeyNestBlock.EGGS);
                if (eggs - 1 <= 0 && state.getValue(TurkeyNestBlock.TEMP)) {
                    server.removeBlock(nest, false);
                } else {
                    server.setBlock(nest, state.setValue(TurkeyNestBlock.EGGS, eggs - 1), 2);
                }
            } else {
                int eggs = state.getValue(FinchNestBlock.EGGS);
                server.setBlock(nest, state.setValue(FinchNestBlock.EGGS, eggs - 1), 3);
            }
            raccoon.setCarryingEgg(true);
            raccoon.setEggSource(nest, turkeyNest);
            raccoon.setStalking(false);
            raccoon.setClimbHint(false);
            server.playSound(null, nest, SoundEvents.ITEM_PICKUP, SoundSource.NEUTRAL, 0.8F, 1.3F);
            server.playSound(null, nest, ModSounds.RACCOON_CHITTER.get(), SoundSource.NEUTRAL, 0.7F, 1.4F);
            if (turkeyNest) {
                // the turkeys see the thief: they sprint after it and peck it
                alertTurkeys(server, raccoon, Vec3.atCenterOf(nest), 10.0D, false);
            }
            beginRun(server);
        }

        // ---------------- phase 2: run to the nearest water
        private void beginRun(ServerLevel server) {
            phase = Phase.RUN;
            timer = 0;
            repath = 0;
            raccoon.setStalking(false);
            water = findWater(server, raccoon.blockPosition(), WATER_RANGE);
        }

        private void tickRun(ServerLevel server) {
            if (water == null || timer > 1600) {
                eatEgg();
                return;
            }
            Vec3 w = Vec3.atCenterOf(water);
            double dx = raccoon.getX() - w.x;
            double dz = raccoon.getZ() - w.z;
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            raccoon.getLookControl().setLookAt(w.x, raccoon.getEyeY(), w.z);
            raccoon.setClimbHint(w.y > raccoon.getY() + 1.0D);
            if (horizontal <= 2.0D || (raccoon.isInWater() && horizontal <= 4.0D)) {
                phase = Phase.WASH;
                timer = 0;
                raccoon.getNavigation().stop();
                raccoon.setWashing(true);
                return;
            }
            if (--repath <= 0) {
                repath = 15;
                raccoon.getNavigation().moveTo(w.x, w.y, w.z, RUN_SPEED);
            }
        }

        // ---------------- phase 3: wash it and leave it on the bottom
        private void tickWash(ServerLevel server) {
            raccoon.getNavigation().stop();
            if (timer % 5 == 0) {
                server.sendParticles(ParticleTypes.SPLASH, raccoon.getX(), raccoon.getY() + 0.3D, raccoon.getZ(),
                        6, 0.3D, 0.1D, 0.3D, 0.05D);
            }
            if (timer == 15) {
                raccoon.playSound(SoundEvents.GENERIC_SPLASH, 0.6F, 1.2F);
            }
            if (timer >= 50) {
                placeEggOnBottom(server);
                raccoon.setCarryingEgg(false);
                raccoon.clearEggSource();
                raccoon.setWashing(false);
                raccoon.playSound(ModSounds.RACCOON_CHITTER.get(), 0.8F, 1.0F);
                finish(6000);
            }
        }

        private void placeEggOnBottom(ServerLevel server) {
            BlockPos origin = raccoon.blockPosition();
            BlockPos best = null;
            double bestDist = Double.MAX_VALUE;
            for (BlockPos p : BlockPos.betweenClosed(origin.offset(-3, -2, -3), origin.offset(3, 2, 3))) {
                if (!server.getFluidState(p).is(FluidTags.WATER)) continue;
                double d = p.distSqr(origin);
                if (d < bestDist) {
                    bestDist = d;
                    best = p.immutable();
                }
            }
            if (best == null) {
                best = water != null ? water : origin;
            }
            BlockPos.MutableBlockPos m = best.mutable();
            int guard = 0;
            while (guard++ < 64 && server.getFluidState(m.below()).is(FluidTags.WATER)) {
                m.move(Direction.DOWN);
            }
            boolean fromTurkey = raccoon.isEggFromTurkey();
            ItemStack eggStack = fromTurkey
                    ? new ItemStack(com.turkeymod.registry.ModItems.TURKEY_EGG.get())
                    : new ItemStack(ModItems.FINCH_EGG.get());
            ItemEntity egg = new ItemEntity(server, m.getX() + 0.5D, m.getY() + 0.2D, m.getZ() + 0.5D, eggStack);
            if (fromTurkey) {
                egg.getPersistentData().putBoolean(WashedEggEvents.WASHED_KEY, true);
            }
            egg.setDeltaMovement(Vec3.ZERO);
            egg.setPickUpDelay(60);
            server.addFreshEntity(egg);
            server.sendParticles(ParticleTypes.BUBBLE, m.getX() + 0.5D, m.getY() + 0.5D, m.getZ() + 0.5D,
                    12, 0.2D, 0.2D, 0.2D, 0.02D);
        }

        // ---------------- endings
        private void eatEgg() {
            raccoon.setCarryingEgg(false);
            raccoon.clearEggSource();
            raccoon.setWashing(false);
            raccoon.playSound(SoundEvents.GENERIC_EAT, 1.0F, 1.0F);
            finish(6000);
        }

        private void finish(int cooldown) {
            raccoon.setStealCooldown(cooldown);
            done = true;
        }
    }
}
