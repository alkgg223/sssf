package com.zebrafinch.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Raccoon, built at 2x resolution (renderer scales it by 0.5). Texture 128x128.
 * Real 3D details: layered fur (shoulder ruff, hip fur, back ridge, belly), cheek tufts, round ears with
 * inner ear, snout + black nose + jaw, clawed paws, a three-piece ringed tail and the stolen egg held in the mouth.
 * Poses: walk / run, sneak (body lowered, legs bent and splayed), carrying the egg, washing the egg.
 */
public class RaccoonModel extends EntityModel<Raccoon> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(ZebraFinchMod.MODID, "raccoon"), "main");

    private static final float BODY_Y = 8.0F;
    private static final float HEAD_Y = 7.0F;
    private static final float HEAD_Z = -9.0F;
    private static final float LEG_Y = 14.0F;

    private final ModelPart root;
    private final ModelPart body, head, frontLeft, frontRight, hindLeft, hindRight;
    private final ModelPart tail1, tail2, tail3, egg;

    public RaccoonModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.frontLeft = root.getChild("front_left");
        this.frontRight = root.getChild("front_right");
        this.hindLeft = root.getChild("hind_left");
        this.hindRight = root.getChild("hind_right");
        this.tail1 = body.getChild("tail1");
        this.tail2 = tail1.getChild("tail2");
        this.tail3 = tail2.getChild("tail3");
        this.egg = head.getChild("egg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition pd = mesh.getRoot();

        // ---------------- BODY + fur layers
        PartDefinition body = pd.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-7F, -6F, -11F, 14F, 12F, 22F),
                PartPose.offset(0F, BODY_Y, 0F));
        body.addOrReplaceChild("back_ridge",
                CubeListBuilder.create().texOffs(0, 90).addBox(-5F, -8F, -6F, 10F, 2F, 12F), PartPose.ZERO);
        body.addOrReplaceChild("belly",
                CubeListBuilder.create().texOffs(46, 90).addBox(-5F, 6F, -8F, 10F, 1F, 16F), PartPose.ZERO);
        body.addOrReplaceChild("shoulder_fur",
                CubeListBuilder.create().texOffs(0, 108).addBox(-8F, -5F, -11F, 16F, 9F, 4F), PartPose.ZERO);
        body.addOrReplaceChild("hip_fur",
                CubeListBuilder.create().texOffs(42, 108).addBox(-8F, -5F, 7F, 16F, 9F, 4F), PartPose.ZERO);

        // ---------------- TAIL: three ringed segments that curve downwards
        PartDefinition tail1 = body.addOrReplaceChild("tail1",
                CubeListBuilder.create().texOffs(0, 74).addBox(-3F, -3F, 0F, 6F, 6F, 7F),
                PartPose.offsetAndRotation(0F, -1F, 10F, -0.1F, 0F, 0F));
        PartDefinition tail2 = tail1.addOrReplaceChild("tail2",
                CubeListBuilder.create().texOffs(28, 74).addBox(-3F, -3F, 0F, 6F, 6F, 7F),
                PartPose.offsetAndRotation(0F, 0F, 7F, -0.15F, 0F, 0F));
        tail2.addOrReplaceChild("tail3",
                CubeListBuilder.create().texOffs(56, 74).addBox(-2.5F, -2.5F, 0F, 5F, 5F, 6F),
                PartPose.offsetAndRotation(0F, 0F, 7F, -0.1F, 0F, 0F));

        // ---------------- HEAD: skull, cheek fur, snout, nose, jaw, ears, held egg
        PartDefinition head = pd.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 36).addBox(-6F, -5F, -8F, 12F, 9F, 9F),
                PartPose.offset(0F, HEAD_Y, HEAD_Z));
        head.addOrReplaceChild("snout",
                CubeListBuilder.create().texOffs(44, 36).addBox(-3F, -1F, -13F, 6F, 5F, 5F), PartPose.ZERO);
        head.addOrReplaceChild("nose",
                CubeListBuilder.create().texOffs(68, 36).addBox(-2F, -1F, -14F, 4F, 3F, 1F), PartPose.ZERO);
        head.addOrReplaceChild("jaw",
                CubeListBuilder.create().texOffs(44, 48).addBox(-2F, 4F, -12F, 4F, 1F, 4F), PartPose.ZERO);
        head.addOrReplaceChild("cheek_l",
                CubeListBuilder.create().texOffs(102, 36).addBox(6F, 0F, -7F, 1F, 4F, 4F), PartPose.ZERO);
        head.addOrReplaceChild("cheek_r",
                CubeListBuilder.create().texOffs(102, 36).addBox(-7F, 0F, -7F, 1F, 4F, 4F), PartPose.ZERO);
        for (String side : new String[]{"l", "r"}) {
            float x = side.equals("l") ? 4F : -4F;
            PartDefinition ear = head.addOrReplaceChild("ear_" + side,
                    CubeListBuilder.create().texOffs(80, 36).addBox(-2F, -3F, -1F, 4F, 3F, 2F),
                    PartPose.offset(x, -5F, -3F));
            ear.addOrReplaceChild("inner_" + side,
                    CubeListBuilder.create().texOffs(94, 36).addBox(-1F, -2F, -1.4F, 2F, 2F, 1F), PartPose.ZERO);
        }
        head.addOrReplaceChild("egg",
                CubeListBuilder.create().texOffs(62, 48).addBox(-2F, 2.5F, -15F, 4F, 5F, 4F), PartPose.ZERO);

        // ---------------- LEGS (dark socks, paw, three toes)
        addLeg(pd, "front_left", 4.5F, -7F, 0, 58, 5);
        addLeg(pd, "front_right", -4.5F, -7F, 0, 58, 5);
        addLeg(pd, "hind_left", 4.5F, 7F, 22, 58, 6);
        addLeg(pd, "hind_right", -4.5F, 7F, 22, 58, 6);

        return LayerDefinition.create(mesh, 128, 128);
    }

    private static void addLeg(PartDefinition pd, String name, float x, float z, int u, int v, int size) {
        float half = size / 2.0F;
        PartDefinition leg = pd.addOrReplaceChild(name,
                CubeListBuilder.create().texOffs(u, v).addBox(-half, 0F, -half, size, 8F, size),
                PartPose.offset(x, LEG_Y, z));
        leg.addOrReplaceChild("paw",
                CubeListBuilder.create().texOffs(48, 58).addBox(-3F, 8F, -4F, 6F, 2F, 7F), PartPose.ZERO);
        for (int i = 0; i < 3; i++) {
            leg.addOrReplaceChild("toe_" + i,
                    CubeListBuilder.create().texOffs(76, 58).addBox(-2.5F + i * 2F, 8.5F, -5F, 1F, 1F, 1F),
                    PartPose.ZERO);
        }
    }

    @Override
    public void setupAnim(Raccoon entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        float deg = (float) Math.PI / 180F;
        float sneak = entity.getSneakAmount();
        boolean carrying = entity.isCarryingEgg();
        boolean washing = entity.isWashing();

        this.egg.visible = carrying;

        // ---- body / head base pose (lower everything while sneaking)
        this.body.y = BODY_Y + 3.0F * sneak;
        this.body.xRot = 0.0F;
        this.head.y = HEAD_Y + 3.5F * sneak;
        this.head.z = HEAD_Z - 1.0F * sneak;
        this.head.xRot = headPitch * deg + 0.30F * sneak - (carrying ? 0.15F : 0.0F);
        this.head.yRot = netHeadYaw * deg;

        // ---- legs: shorter + splayed when sneaking
        float legY = LEG_Y + 3.0F * sneak;
        float legScale = 1.0F - 0.30F * sneak;
        ModelPart[] legs = {frontLeft, frontRight, hindLeft, hindRight};
        for (ModelPart leg : legs) {
            leg.y = legY;
            leg.yScale = legScale;
        }
        float swing = limbSwing * 0.6662F;
        float amp = 1.2F * limbSwingAmount * (1.0F - 0.3F * sneak);
        this.frontLeft.xRot = Mth.cos(swing) * amp;
        this.hindRight.xRot = Mth.cos(swing) * amp;
        this.frontRight.xRot = Mth.cos(swing + (float) Math.PI) * amp;
        this.hindLeft.xRot = Mth.cos(swing + (float) Math.PI) * amp;
        this.frontLeft.zRot = -0.28F * sneak;
        this.hindLeft.zRot = -0.28F * sneak;
        this.frontRight.zRot = 0.28F * sneak;
        this.hindRight.zRot = 0.28F * sneak;

        // ---- tail: gentle wag, lags along the segments, low while sneaking, lifted when running
        float t = ageInTicks * 0.08F;
        float run = Mth.clamp(limbSwingAmount, 0.0F, 1.0F);
        this.tail1.xRot = -0.1F - 0.30F * sneak + 0.25F * run;
        this.tail1.yRot = Mth.sin(t) * 0.12F + Mth.cos(swing) * 0.18F * limbSwingAmount;
        this.tail2.yRot = Mth.sin(t - 0.8F) * 0.14F;
        this.tail3.yRot = Mth.sin(t - 1.6F) * 0.16F;

        // ---- washing the egg: head down, front paws rubbing it
        if (washing) {
            float s = Mth.sin(ageInTicks * 0.6F);
            this.head.xRot = 0.85F + 0.12F * s;
            this.head.y += 1.5F;
            this.body.xRot = 0.12F;
            this.frontLeft.xRot = -1.0F + 0.45F * s;
            this.frontRight.xRot = -1.0F - 0.45F * s;
            this.hindLeft.xRot = 0.0F;
            this.hindRight.xRot = 0.0F;
            this.tail1.xRot = 0.1F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, color);
    }
}
