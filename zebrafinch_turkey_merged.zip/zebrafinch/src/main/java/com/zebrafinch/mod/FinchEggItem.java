package com.zebrafinch.mod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/**
 * Egg stolen from a nest. When it lies in water (a raccoon "washes" it) it stays on the bottom and after
 * one minute it is ruined and turns into a spoiled egg.
 */
public class FinchEggItem extends Item {
    public static final int SPOIL_TICKS = 20 * 60;
    private static final String SOAK_KEY = "zebrafinch_soak";

    public FinchEggItem(Properties properties) {
        super(properties);
    }

    @Override
    public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        if (entity.isInWater()) {
            Vec3 m = entity.getDeltaMovement();
            entity.setDeltaMovement(m.x * 0.5D, Math.min(m.y, -0.02D), m.z * 0.5D);
            if (!entity.level().isClientSide && entity.level() instanceof ServerLevel server) {
                int soak = entity.getPersistentData().getInt(SOAK_KEY) + 1;
                entity.getPersistentData().putInt(SOAK_KEY, soak);
                if (soak >= SPOIL_TICKS) {
                    entity.setItem(new ItemStack(ModItems.SPOILED_EGG.get(), stack.getCount()));
                    server.playSound(null, entity.blockPosition(), SoundEvents.TURTLE_EGG_CRACK,
                            SoundSource.NEUTRAL, 0.8F, 0.7F);
                    server.sendParticles(ParticleTypes.BUBBLE, entity.getX(), entity.getY() + 0.2D, entity.getZ(),
                            10, 0.2D, 0.1D, 0.2D, 0.02D);
                }
            }
        }
        return false;
    }
}
