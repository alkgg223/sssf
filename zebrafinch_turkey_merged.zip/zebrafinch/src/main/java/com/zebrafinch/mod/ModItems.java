package com.zebrafinch.mod;

import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ZebraFinchMod.MODID);

    public static final DeferredItem<DeferredSpawnEggItem> SPAWN_EGG = ITEMS.register("zebra_finch_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ZEBRA_FINCH, 0xA39D96, 0xF57C12, new Item.Properties()));

    public static final DeferredItem<DeferredSpawnEggItem> RACCOON_SPAWN_EGG = ITEMS.register("raccoon_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.RACCOON, 0x8C8C8C, 0x21212A, new Item.Properties()));

    /** An egg stolen by a raccoon. Left in water for a minute it spoils. */
    public static final DeferredItem<FinchEggItem> FINCH_EGG = ITEMS.register("finch_egg",
            () -> new FinchEggItem(new Item.Properties().stacksTo(16)));

    public static final DeferredItem<Item> SPOILED_EGG = ITEMS.registerSimpleItem("spoiled_finch_egg");

    public static final DeferredItem<Item> DROPPING = ITEMS.registerSimpleItem("finch_dropping");

    public static final DeferredItem<net.minecraft.world.item.BlockItem> NEST_ITEM =
            ITEMS.registerSimpleBlockItem("finch_nest", ModBlocks.NEST);
}
