package com.zebrafinch.mod;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * A turkey egg that a raccoon left on the bottom of the water stays there and spoils after a minute
 * (finch eggs do the same inside FinchEggItem). Only eggs marked by the raccoon are affected.
 */
@EventBusSubscriber(modid = ZebraFinchMod.MODID)
public class WashedEggEvents {
    public static final String WASHED_KEY = "zebrafinch_washed";
    private static final String SOAK_KEY = "zebrafinch_soak";

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Pre event) {
        if (!(event.getEntity() instanceof ItemEntity item)) {
            return;
        }
        if (!item.getPersistentData().getBoolean(WASHED_KEY) || !item.isInWater()) {
            return;
        }
        Vec3 m = item.getDeltaMovement();
        item.setDeltaMovement(m.x * 0.5D, Math.min(m.y, -0.02D), m.z * 0.5D);
        if (item.level() instanceof ServerLevel server) {
            int soak = item.getPersistentData().getInt(SOAK_KEY) + 1;
            item.getPersistentData().putInt(SOAK_KEY, soak);
            if (soak >= FinchEggItem.SPOIL_TICKS) {
                item.setItem(new ItemStack(ModItems.SPOILED_EGG.get(), item.getItem().getCount()));
                item.getPersistentData().remove(WASHED_KEY);
                server.playSound(null, item.blockPosition(), SoundEvents.TURTLE_EGG_CRACK,
                        SoundSource.NEUTRAL, 0.8F, 0.7F);
                server.sendParticles(ParticleTypes.BUBBLE, item.getX(), item.getY() + 0.2D, item.getZ(),
                        10, 0.2D, 0.1D, 0.2D, 0.02D);
            }
        }
    }
}
