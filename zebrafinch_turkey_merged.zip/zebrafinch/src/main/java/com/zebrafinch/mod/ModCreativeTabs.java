package com.zebrafinch.mod;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** One dedicated creative tab: turkey, zebra finch, raccoon and both nests. */
public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ZebraFinchMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> CREATURES = TABS.register("creatures",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.zebrafinch.creatures"))
                    .icon(() -> new ItemStack(ModItems.SPAWN_EGG.get()))
                    .displayItems((params, output) -> {
                        output.accept(com.turkeymod.registry.ModItems.TURKEY_SPAWN_EGG.get());
                        output.accept(ModItems.SPAWN_EGG.get());
                        output.accept(ModItems.RACCOON_SPAWN_EGG.get());
                        output.accept(com.turkeymod.registry.ModItems.TURKEY_NEST.get());
                        output.accept(ModItems.NEST_ITEM.get());
                    })
                    .build());
}
